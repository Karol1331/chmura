<?php 
    $server = "localhost";
    $db_user = "root";
    $db_password = "";
    $db = "reg-log_system";
?>