<?php
    session_start();
    require_once("connect.php");

    if (!isset($_POST['wyslij'])) {
        header("Location: ../www/reg_www.php");
        return;
    }

    $login = trim($_POST['login']);
    $mail = trim($_POST['mail']);
    $pass = trim($_POST['pass']);

    if (empty($login) || empty($pass) || empty($pass)) {
        $_SESSION['regErr'] = "Wypełnij wszystkie pola!";
        header("Location: ../www/reg_www.php");
        return;
    }
    if (strpos($login, ' ') || strpos($login, '@')) {
        $_SESSION['regErr'] = "Login nie może zawierać spacji oraz znaku @";
        header("Location: ../www/reg_www.php");
        return;
    }

    $conn = new mysqli($server, $db_user, $db_password, $db);
    if (!$conn) die ("Wystąpił błąd! Spróbuj ponownie później!");

    $login = $conn->real_escape_string($login);
    $mail = $conn->real_escape_string($mail);
    $pass = $conn->real_escape_string($pass);
    $hash = password_hash($pass, PASSWORD_DEFAULT);

    $kod = rand(11111, 99999);

    $sql = "INSERT INTO users (login, mail, password, aktywne) VALUES ('$login', '$mail', '$hash', '$kod')";
    $conn->query($sql);

    $conn->close();
    $_SESSION['zarejestrowano'] = "Zarejestrowano pomyślnie konto! Sprawdź maila, aby aktywować konto!";
    $link = "localhost/log-reg/www/weryfikacja_www.php?kod=".$kod;

    $subject = "Aktywacja konta";
    $body = "Witaj!\n$link - Kliknij aby aktywować konto!</a>";
    mail($mail, $subject, $body);

    header("Location: ../index.php");
?>