<?php
    require_once("../php/connect.php");
    session_start();

    if (isset($_GET['kod'])) {
        $kod = $_GET['kod'];

        $conn = new mysqli($server, $db_user, $db_password, $db);

        $sql = "UPDATE users SET aktywne = NULL WHERE aktywne = '$kod'";
        $conn->query($sql);

        $_SESSION['zarejestrowano'] = "Aktywowano konto!";
        header("Location: ../index.php");
    }
?>