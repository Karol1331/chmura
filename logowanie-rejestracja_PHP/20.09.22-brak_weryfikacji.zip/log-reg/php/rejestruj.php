<?php
    session_start();
    require_once("connect.php");

    if (!isset($_POST['wyslij'])) {
        header("Location: ../www/reg_www.php");
        return;
    }

    $login = trim($_POST['login']);
    $mail = trim($_POST['mail']);
    $pass = trim($_POST['pass']);

    if (empty($login) || empty($pass) || empty($pass)) {
        $_SESSION['regErr'] = "Wypełnij wszystkie pola!";
        header("Location: ../www/reg_www.php");
        return;
    }
    if (strpos($login, ' ') || strpos($login, '@')) {
        $_SESSION['regErr'] = "Login nie może zawierać spacji oraz znaku @";
        header("Location: ../www/reg_www.php");
        return;
    }

    $conn = new mysqli($server, $db_user, $db_password, $db);
    if (!$conn) die ("Wystąpił błąd! Spróbuj ponownie później!");

    $login = $conn->real_escape_string($login);
    $mail = $conn->real_escape_string($mail);
    $pass = $conn->real_escape_string($pass);
    $hash = password_hash($pass, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (login, mail, password) VALUES ('$login', '$mail', '$hash')";
    $conn->query($sql);

    $conn->close();
    $_SESSION['zarejestrowano'] = "Zarejestrowano pomyślnie konto!";
    header("Location: ../index.php");
?>