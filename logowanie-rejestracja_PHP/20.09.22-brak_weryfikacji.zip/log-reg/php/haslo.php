<?php 
    require_once("connect.php");

    if(!isset($_POST['mail-odzyskiwanie'])) {
        header("Location: ../www/odzyskiwanie.php");
        return;
    }

    $mail = $_POST['mail-odzyskiwanie'];
    $conn = new mysqli($server, $db_user, $db_password, $db);

    $kod = rand(11111, 99999);
    $sql = "UPDATE users SET kod_odzyskiwania = '$kod' WHERE mail = '$mail'";

    $conn->query($sql);
    $conn->close();

    $link = "localhost/log-reg/www/haslo_www.php?kod=".$kod;
    $subject = "Odzyskiwanie hasła";
    $body = "Witaj!<br><a href='$link'>Kliknij aby zresetować hasło!</a>";
    
    //mail($mail, $subject, $body);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../skopiowany.css">
    <title>Odzyskiwanie hasła</title>
</head>
<body>
<div class="bg" aria-hidden="true">
        <div class="bg__dot"></div>
        <div class="bg__dot"></div>
    </div>
    <section class="form">
        <?php
            if(mail($mail, $subject, $body)) {
                echo '<div class="form__button" style="color: black;">E-mail resetujący hasło został wysłany! Sprawdź swoją pocztę!</div>';
            }
        ?>
    </section>
</body>
</html>