<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="skopiowany.css">
    <title>Strona Główna</title>
</head>

<body>
    <div class="bg" aria-hidden="true">
        <div class="bg__dot"></div>
        <div class="bg__dot"></div>
    </div>
    <section class="form">
        <div class="form__button" style="color: black;" onclick="document.location = 'www/reg_www.php'">REJESTRACJA</div> <br>
        <div class="form__button" style="color: black;" onclick="document.location = 'www/log_www.php'">LOGOWANIE</div>
    </section>
    <?php 
        if(isset($_SESSION['zarejestrowano'])) {
            echo "<p class='blad' style='color: green'>{$_SESSION['zarejestrowano']}</p>";
            unset($_SESSION['zarejestrowano']);
        }
    ?>
    <div class="form__button" id="autor" onclick="window.open('https://youtu.be/L9F5mIUpnkA')">Autor CSS</div>
</body>

</html>