<?php
    session_start();
    require_once("connect.php");

    if (!isset($_POST['wyslij'])) {
        header("Location: log_www.php");
        return;
    }

    $conn = new mysqli($server, $db_user, $db_password, $db);

    $logmail = $conn->real_escape_string($_POST['log-mail']);
    $pass = $conn->real_escape_string($_POST['pass']);
    $logmethod = (strpos($logmail, '@') === false) ? "login" : "mail";

    $sql = "SELECT * FROM users WHERE $logmethod = '$logmail'";

    if ($result = $conn->query($sql)) {
        if ($result->num_rows > 0) {
            $wiersz = $result->fetch_assoc();
            if (password_verify($pass, $wiersz['password'])) {
                $_SESSION['login'] = $wiersz['login'];
                $_SESSION['hash'] = $wiersz['password'];
                $_SESSION['mail'] = $wiersz['mail'];

                $result->close();
                header("Location: ../www/zalogowany.php");
            }
            else {
                $_SESSION['logErr'] = "Nieprawidłowy login/e-mail lub hasło!";
                header("Location: log_www.php");
            }
        }
        else {
            $_SESSION['logErr'] = "Nieprawidłowy login/e-mail lub hasło!";
            header("Location: log_www.php");
        }
    }
    else die("Wystąpił błąd!");

    $conn->close();
?>