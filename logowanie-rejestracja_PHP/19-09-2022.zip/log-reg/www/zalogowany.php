<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../skopiowany.css">
    <title>KONTO</title>
</head>
<body>
    <div class="bg" aria-hidden="true">
        <div class="bg__dot"></div>
        <div class="bg__dot"></div>
    </div>
    <section class="form">
        <?php 
            if (!isset($_SESSION['login'])) {
                header("Location: log_www.php");
                return;
            }
            
            echo "<b>Login: </b><br>{$_SESSION['login']}<br>";
            echo "<b>E-mail: </b><br>{$_SESSION['mail']}<br>";
            echo "<b>Hash: </b><br>{$_SESSION['hash']}<br>";
        ?>
        <br>
        <button class="form__button" onclick="document.location = '../php/wyloguj.php'">Wyloguj</button>
    </section>
    <div class='form__input-container'></div>
</body>
</html>