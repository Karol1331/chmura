<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../skopiowany.css">
    <title>Logowanie</title>
</head>
<body>
    <!-- <form action="rejestruj.php" method="post">
        <label for="log-mail">Login lub e-mail:</label><br>
        <input type="text" name="log-mail"><br>
        <label for="pass">Hasło:</label><br>
        <input type="password" name="pass"><br>
        <input type="submit" name="wyslij" value="Zarejestruj">
    </form> -->
    <div class="bg" aria-hidden="true">
        <div class="bg__dot"></div>
        <div class="bg__dot"></div>
    </div>
    <form action="../php/loguj.php" method="post" class="form" autocomplete="off">
        <h3>LOGOWANIE</h3><br>
        <div class="form__input-container">
            <input
                aria-label="User"
                class="form__input"
                type="text"
                name="log-mail"
                id="user"
                placeholder=" "
            />
            <label class="form__input-label" for="user">Login lub e-mail</label>
        </div>
        <div class="form__input-container">
            <input
                aria-label="Password"
                class="form__input"
                type="password"
                name="pass"
                id="password"
                placeholder=" "
            />
            <label class="form__input-label" for="password">Hasło</label>
        </div>
        <div class="form__spacer" aria-hidden="true"></div>
        <button class="form__button" name="wyslij">Zaloguj</button>
    </form>
    <?php
        if (isset($_SESSION['logErr'])) {
            echo "<p class='blad'>{$_SESSION['logErr']}</p>";
            unset($_SESSION['regErr']);
        }
    ?>
    <div class="form__button" id="autor" onclick="window.open('https://youtu.be/L9F5mIUpnkA')">Autor CSS</div>
</body>
</html>