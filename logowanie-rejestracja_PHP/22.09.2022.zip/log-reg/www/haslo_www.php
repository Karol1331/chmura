<?php
    require_once("../php/connect.php");
    session_start();

    if (isset($_POST['newpass'])) {
        $kod = $_GET['kod'];
        $haslo = $_POST['newpass'];
        $hash = password_hash($haslo, PASSWORD_DEFAULT);

        $conn = new mysqli($server, $db_user, $db_password, $db);

        $sql = "UPDATE users SET password = '$hash', kod_odzyskiwania = NULL WHERE kod_odzyskiwania = '$kod'";
        $conn->query($sql);

        $_SESSION['zarejestrowano'] = "Zresetowano hasło!";
        header("Location: ../index.php");
    }
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../skopiowany.css">
    <title>Odzyskiwanie hasła</title>
</head>
<body>
<form method="post" class="form" autocomplete="off">
        <h3>ODZYSKIWANIE</h3><br>
        <div class="form__input-container">
            <input
                aria-label="Password"
                class="form__input"
                type="password"
                name="newpass"
                id="password"
                placeholder=" "
            />
            <label class="form__input-label" for="password">Nowe hasło</label>
        </div>
        <div class="form__spacer" aria-hidden="true"></div>
        <button class="form__button">USTAW NOWE HASŁO</button>
    </form>
</body>
</html>