<?php
    require_once("../php/connect.php");
    session_start();

    if (isset($_GET['kod']) && isset($_GET['mail'])) {
        $kod = $_GET['kod'];
        $mail = $_GET['mail'];

        $conn = new mysqli($server, $db_user, $db_password, $db);

        $sql = "UPDATE users SET aktywne = NULL WHERE aktywne = '$kod' AND mail = '$mail'";
        $conn->query($sql);

        $_SESSION['zarejestrowano'] = "Aktywowano konto!";
        header("Location: ../index.php");
    }
?>