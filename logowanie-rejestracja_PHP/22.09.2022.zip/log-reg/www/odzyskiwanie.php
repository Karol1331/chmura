<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../skopiowany.css">
    <title>Odzyskiwanie hasła</title>
</head>
<body>
    <form action="../php/haslo.php" method="post" class="form" autocomplete="off">
        <h3>Odzyskiwanie hasła</h3><br>
        <div class="form__input-container">
            <input
                aria-label="User"
                class="form__input"
                type="text"
                name="mail-odzyskiwanie"
                id="user"
                placeholder=" "
            />
            <label class="form__input-label" for="user">Adres e-mail</label>
        </div>
        <div class="form__spacer" aria-hidden="true"></div>
        <button class="form__button" name="wyslij">Odzyskaj</button><br>
    </form>
</body>
</html>