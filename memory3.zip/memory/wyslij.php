<?php
    $conn = new mysqli("localhost", "root", "", "memorybase");
    if(empty($_POST['login']) || empty($_POST['plansza']) || empty($_POST['czas']) || empty($_POST['klikniecia'])) {
        header("Location: index.php");
        return;
    }
    $sql = "INSERT INTO ranking VALUES (NULL, '{$_POST['login']}', {$_POST['plansza']}, '{$_POST['czas']}', {$_POST['klikniecia']})";
    $conn->query($sql);
    $conn->close();
    header("Location: index.php");
?>