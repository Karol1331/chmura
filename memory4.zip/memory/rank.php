<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="my.css">
    <title>Ranking</title>
</head>
<body onload="scaleRanks()">
    <?php
    $conn = new mysqli ("localhost", "root", "", "memorybase");
    ?>
    <div class="glowny rank">
        <h2>Wersja 1</h2>
        <ol>
            <?php
            $sql = "SELECT * FROM ranking WHERE wersja = 'v1' ORDER BY czas";
            if ($result = $conn->query($sql))
            {
                foreach($result as $row)
                {
                    echo "<li>{$row['login']} - {$row['czas']}sec</li>";
                }
            }
            ?>
        </ol>
    </div>
    <div class="glowny rank">
        <h2>Wersja 2</h2>
        <ol>
            <?php
            $sql = "SELECT * FROM ranking WHERE wersja = 'v2' ORDER BY czas";
            if ($result = $conn->query($sql))
            {
                foreach($result as $row)
                {
                    echo "<li>{$row['login']} - {$row['czas']}sec</li>";
                }
            }
            ?>
        </ol>
    </div>
    <div class="form__button" id="exit" onclick="document.location = 'index.php'">Powrót</div>
    <?php
    $conn->close();
    ?>
</body>
</html>