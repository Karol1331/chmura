CREATE TABLE `ranking` (
  `id` int(11) NOT NULL,
  `login` text NOT NULL,
  `plansza` int(11) NOT NULL,
  `czas` int(11) NOT NULL,
  `klikniecia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `ranking`
  ADD PRIMARY KEY (`id`);

  ALTER TABLE `ranking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;