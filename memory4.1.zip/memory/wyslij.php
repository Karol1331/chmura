<?php
    $conn = new mysqli("localhost", "root", "", "memorybase");
    if(empty($_POST['login']) || empty($_POST['versja']) || empty($_POST['versja']) || empty($_POST['czas']) || empty($_POST['klikniecia'])) {
        header("Location: index.php");
        return;
    }
    $sql = "INSERT INTO ranking VALUES (NULL, '{$_POST['login']}', '{$_POST['versja']}', '{$_POST['czas']}', {$_POST['klikniecia']}, {$_POST['plansza']})";
    $conn->query($sql);
    $conn->close();
    header("Location: index.php");
?>