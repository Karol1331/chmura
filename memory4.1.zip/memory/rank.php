<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="my.css">
    <title>Ranking</title>
</head>
<body onload="scaleRanks()">
    <div class="exit" id="from">
        <form action="" method="post">
            <select name="plansza" id="poziom">
                <option value="" selected hidden>Wybierz planszę</option>
                <option value="2">2x2</option>
                <option value="4">4x4</option>
                <option value="8">8x8</option>
            </select>
            <label>Wersja 1<input type="radio" name="ver" value="v1" id="v1"></label>
            <label>Wersja 2<input type="radio" name="ver" value="v2" id="v2"></label>
            <input type="submit" name="sub" value="POKAŻ RANKING">
        </form>
    </div>
    <div class="glowny rank">
        <?php
        if(isset($_POST['sub']))
        {
            echo "<h2>{$_POST['plansza']}x{$_POST['plansza']} ";
            echo $_POST['ver'] == "v1" ? "Wersja 1" : "Wersja 2";
            echo "</h2>";
            $conn = new mysqli ("localhost", "root", "", "memorybase");
            echo "<ol>";
            $sql = "SELECT * FROM ranking WHERE wersja = '{$_POST['ver']}' AND plansza = '{$_POST['plansza']}' ORDER BY czas";
            if ($result = $conn->query($sql))
            {
                foreach($result as $row)
                {
                    echo "<li>{$row['login']} - {$row['czas']}sec, {$row['klikniecia']} kliknięć</li>";
                }
            }
            echo "</ol>";
            $conn->close();
        }
        else echo "<h2>WYBIERZ RANKING</h2>";
        ?>
    </div>
    <div class="exit" onclick="document.location = 'index.php'">Powrót</div>
</body>
</html>